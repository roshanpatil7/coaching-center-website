// header and footer include code starts here

fetch('Header.html')
  .then(response => response.text())
  .then(data => {
    document.getElementById('header-placeholder').innerHTML = data;
  })
  .catch(error => console.error('Error loading header:', error));


// footer and footer include code starts here

fetch('Footer.html')
  .then(response => response.text())
  .then(data => {
    document.getElementById('Footer-placeholder').innerHTML = data;
  })
  .catch(error => console.error('Error loading header:', error));